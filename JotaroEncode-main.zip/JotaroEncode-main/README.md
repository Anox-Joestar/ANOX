[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
::
Oof 
Your Bot Father Setting to put
```
start - Check Bot Alive💋
help - check For Your Knowledge
eval - For Checking Cmds
crf - Your CRF Helper
codec - Your Codec Setting
preset - Your Preset Setting
resolution - Your Resolution Setting
audio - Your Audio Setting
settings - Check Current Ffmpeg Code Settings
```
